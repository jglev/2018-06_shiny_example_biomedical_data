# .onAttach <- function(...) {
#
#   if (!interactive()) return()
#
#   packageStartupMessage(paste0("vegalite is under *active* development. ",
#                                "See https://github.com/hrbrmstr/vegalite for changes"))
#
# }