library(testthat)
library(vegalite)
library(jsonlite)

test_check("vegalite")
